package com.example.smarthomeforstroke

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ReExercise : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_re_exercise)



    }
}